use bankmanagementsystem;

create table sign_up2(name varchar(40),username2 varchar(20),dob varchar(20),email varchar(100),pass varchar(20),c_pass varchar(20),cnic varchar(20),city varchar(20));
show tables;
select * from sign_up2;

create table admin_table (admin VARCHAR(255),username2 varchar(20),dob varchar(20),email varchar(100),pass varchar(20),c_pass varchar(20),cnic varchar(20),city varchar(20));
select * from admin_table;

create table reciept(username varchar (40),name varchar(40),model varchar(40),price varchar(40), average varchar(40),Owner varchar(100),Date1 varchar(50),Date2 varchar(50));
select * from reciept;

create table cars(name varchar(40),model varchar(40),price varchar(40), average varchar(40),Owner varchar(100));
select * from cars;
ALTER TABLE cars ADD COLUMN status VARCHAR(20) DEFAULT 'Available';
ALTER TABLE cars MODIFY COLUMN status VARCHAR(20) DEFAULT 'Available';
drop table cars;

create table comp(username varchar (40),complaint varchar(4000),owner varchar(40));
select * from comp;
ALTER TABLE comp ADD COLUMN status VARCHAR(20) DEFAULT 'unresolved';

